package com.sely.assistant

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import java.util.Locale

/** One line of the shared chat transcript. */
data class ChatMessage(val text: String, val isUser: Boolean)

/** Implemented by whichever fragment is currently showing the chat, to receive live updates. */
interface ChatListener {
    fun onChatMessageAdded(message: ChatMessage)
}

class MainActivity : AppCompatActivity(), SelyCommandProcessor.Callbacks {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navView: NavigationView
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var prefs: SharedPreferences
    private lateinit var textToSpeech: TextToSpeech
    private var ttsReady = false

    private val commandProcessor by lazy { SelyCommandProcessor(this, this) }

    // Fragments are kept alive and shown/hidden so chat scroll position, drafts, etc. survive
    // switching tabs.
    private val homeFragment = HomeFragment()
    private val chatFragment = ChatFragment()
    private val toolsFragment = ToolsFragment()
    private val settingsFragment = SettingsFragment()
    private var activeFragment: Fragment = homeFragment

    private val chatHistory = mutableListOf<ChatMessage>()
    private var chatListener: ChatListener? = null

    var isWakeServiceRunning = false
        private set

    private val requiredPermissions: Array<String>
        get() {
            val base = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CAMERA
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                base.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            base.add(Manifest.permission.READ_PHONE_STATE)
            base.add(Manifest.permission.READ_CALL_LOG)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                base.add(Manifest.permission.ANSWER_PHONE_CALLS)
            }
            return base.toTypedArray()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("sely_prefs", Context.MODE_PRIVATE)
        isWakeServiceRunning = prefs.getBoolean("always_listen_enabled", false)

        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val savedLang = prefs.getString("sely_language", "en-US") ?: "en-US"
                textToSpeech.language = Locale.forLanguageTag(savedLang)
                ttsReady = true
            }
        }

        drawerLayout = findViewById(R.id.drawerLayout)
        navView = findViewById(R.id.navView)
        bottomNav = findViewById(R.id.bottomNav)
        val menuButton = findViewById<android.widget.ImageButton>(R.id.menuButton)
        val profileButton = findViewById<android.widget.ImageButton>(R.id.profileButton)

        menuButton.setOnClickListener { drawerLayout.openDrawer(GravityCompat.START) }
        profileButton.setOnClickListener { showAppInfoDialog() }

        supportFragmentManager.beginTransaction()
            .add(R.id.fragmentContainer, settingsFragment, "settings").hide(settingsFragment)
            .add(R.id.fragmentContainer, toolsFragment, "tools").hide(toolsFragment)
            .add(R.id.fragmentContainer, chatFragment, "chat").hide(chatFragment)
            .add(R.id.fragmentContainer, homeFragment, "home")
            .commit()

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> showTab(homeFragment)
                R.id.nav_chat -> showTab(chatFragment)
                R.id.nav_tools -> showTab(toolsFragment)
                R.id.nav_settings -> showTab(settingsFragment)
            }
            true
        }

        navView.setNavigationItemSelectedListener { item ->
            drawerLayout.closeDrawer(GravityCompat.START)
            when (item.itemId) {
                R.id.drawer_home -> { bottomNav.selectedItemId = R.id.nav_home }
                R.id.drawer_chat_history -> { bottomNav.selectedItemId = R.id.nav_chat }
                R.id.drawer_voice_assistant -> startActivity(Intent(this, VoiceAssistantActivity::class.java))
                R.id.drawer_study_mode -> {
                    bottomNav.selectedItemId = R.id.nav_chat
                    chatFragment.prefillInput("Help me study: ")
                }
                R.id.drawer_settings -> { bottomNav.selectedItemId = R.id.nav_settings }
                R.id.drawer_about -> showAppInfoDialog()
            }
            true
        }

        requestNeededPermissions()
        handleWakeIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWakeIntent(intent)
    }

    // SelyWakeService executes commands directly and only opens MainActivity when there's
    // nothing to run headlessly (a typed/tapped follow-up makes sense in the Chat tab).
    private fun handleWakeIntent(intent: Intent) {
        val pendingCommand = intent.getStringExtra("pending_command")
        if (!pendingCommand.isNullOrEmpty()) {
            bottomNav.selectedItemId = R.id.nav_chat
            submitCommand(pendingCommand)
        }
    }

    private fun showTab(fragment: Fragment) {
        if (fragment == activeFragment) return
        supportFragmentManager.beginTransaction()
            .hide(activeFragment)
            .show(fragment)
            .commit()
        activeFragment = fragment
    }

    private fun requestNeededPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    // ---- Shared chat transcript, so Home's ask box / wake word / Chat tab all agree ----
    fun getChatHistory(): List<ChatMessage> = chatHistory

    fun setChatListener(listener: ChatListener?) {
        chatListener = listener
    }

    private fun addToHistory(message: ChatMessage) {
        chatHistory.add(message)
        if (chatHistory.size > 200) chatHistory.removeAt(0)
        chatListener?.onChatMessageAdded(message)
    }

    /** Runs [text] through the shared command processor. Optionally switches to the Chat tab first. */
    fun submitCommand(text: String, switchToChat: Boolean = true) {
        if (text.isBlank()) return
        addToHistory(ChatMessage(text, isUser = true))
        if (switchToChat) bottomNav.selectedItemId = R.id.nav_chat
        commandProcessor.process(text.lowercase())
    }

    fun goToChat() { bottomNav.selectedItemId = R.id.nav_chat }
    fun goToTools() { bottomNav.selectedItemId = R.id.nav_tools }
    fun findFragmentTag(tag: String): Fragment? = supportFragmentManager.findFragmentByTag(tag)

    fun openBrowserSearch() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com")))
        } catch (e: Exception) {
            Toast.makeText(this, "No browser available", Toast.LENGTH_SHORT).show()
        }
    }

    // ---- SelyCommandProcessor.Callbacks ----
    override fun speak(text: String, onDone: (() -> Unit)?) {
        runOnUiThread {
            addToHistory(ChatMessage(text, isUser = false))
            if (ttsReady) {
                textToSpeech.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { runOnUiThread { onDone?.invoke() } }
                    override fun onError(utteranceId: String?) { runOnUiThread { onDone?.invoke() } }
                })
                textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sely_utterance")
            } else {
                onDone?.invoke()
            }
        }
    }

    // ---- Settings-facing helpers (called from SettingsFragment) ----
    fun setSelyLanguage(code: String) {
        prefs.edit().putString("sely_language", code).apply()
        if (ttsReady) textToSpeech.language = Locale.forLanguageTag(code)
    }

    fun toggleWakeService() {
        val serviceIntent = Intent(this, SelyWakeService::class.java)
        if (isWakeServiceRunning) {
            stopService(serviceIntent)
            isWakeServiceRunning = false
            prefs.edit().putBoolean("always_listen_enabled", false).apply()
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            isWakeServiceRunning = true
            prefs.edit().putBoolean("always_listen_enabled", true).apply()
        }
    }

    fun requestAssistantRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
                if (roleManager.isRoleHeld(RoleManager.ROLE_ASSISTANT)) {
                    Toast.makeText(this, "Sely is already your default assistant", Toast.LENGTH_SHORT).show()
                } else {
                    startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT), REQ_ASSISTANT_ROLE)
                }
            } else {
                Toast.makeText(this, "The assistant role isn't available on this device", Toast.LENGTH_SHORT).show()
            }
        } else {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            }
        }
    }

    private fun showAppInfoDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Sely")
            .setMessage("Version 1.0.0\nYour Smart AI Companion\n\nDesigned by Kingsley \uD83D\uDC51")
            .setPositiveButton("Close", null)
            .show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun onDestroy() {
        textToSpeech.stop()
        textToSpeech.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val REQ_ASSISTANT_ROLE = 501
    }
}

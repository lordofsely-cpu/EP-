package com.sely.assistant

import android.app.admin.DeviceAdminReceiver

class SelyDeviceAdminReceiver : DeviceAdminReceiver()
